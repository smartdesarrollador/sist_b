<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Ejemplo básico de Vue en Blade</title>
    <script src="https://cdn.jsdelivr.net/npm/vue@2.6.14/dist/vue.min.js"></script>
</head>

<body>
    <div id="app">
        <p><?php echo e(mensaje); ?></p>
    </div>

    <script>
        var app = new Vue({
            el: '#app',
            data: {
                mensaje: 'Hola mundo!'
            }
        });
    </script>
</body>

</html>
<?php /**PATH C:\wamp\www\sist_b\resources\views/inicio.blade.php ENDPATH**/ ?>